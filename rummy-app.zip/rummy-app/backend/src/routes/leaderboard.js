const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

const router = Router();

// ─── Leaderboard ─────────────────────────────────────────
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { page = 1, limit = 50, tier } = req.query;
    const conditions = [];
    const values = [];
    let idx = 1;

    if (tier !== undefined) {
      conditions.push(`l.rank_tier = $${idx++}`);
      values.push(parseInt(tier));
    }

    const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

    const { rows } = await db.query(
      `SELECT ROW_NUMBER() OVER (ORDER BY l.rank_tier DESC, l.season_pts DESC, l.games_won DESC) AS rank,
              u.username, u.display_name, u.avatar_url, u.vip_level, u.country,
              l.games_played, l.games_won,
              CASE WHEN l.games_played > 0 THEN ROUND(100.0 * l.games_won / l.games_played, 1) ELSE 0 END AS win_rate,
              l.highest_score, l.best_streak, l.rank_tier, l.season_pts
       FROM leaderboard l
       JOIN users u ON u.id = l.user_id
       ${where}
       ORDER BY l.rank_tier DESC, l.season_pts DESC, l.games_won DESC
       LIMIT $${idx} OFFSET $${idx + 1}`,
      [...values, parseInt(limit), (parseInt(page) - 1) * parseInt(limit)]
    );

    res.json({ leaderboard: rows, page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch leaderboard.' } });
  }
});

// ─── My Rank ─────────────────────────────────────────────
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT * FROM (
         SELECT ROW_NUMBER() OVER (ORDER BY l.rank_tier DESC, l.season_pts DESC, l.games_won DESC) AS rank,
                l.user_id, l.games_played, l.games_won, l.highest_score, l.best_streak, l.rank_tier, l.season_pts
         FROM leaderboard l
         JOIN users u ON u.id = l.user_id
         WHERE u.is_banned = FALSE
       ) sub WHERE sub.user_id = $1`,
      [req.user.id]
    );
    res.json(rows[0] || { rank: null });
  } catch (err) {
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch rank.' } });
  }
});

// ─── Friends Leaderboard ─────────────────────────────────
router.get('/friends', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT ROW_NUMBER() OVER (ORDER BY l.season_pts DESC) AS rank,
              u.username, u.display_name, u.avatar_url,
              l.games_played, l.games_won, l.best_streak, l.rank_tier, l.season_pts
       FROM leaderboard l
       JOIN users u ON u.id = l.user_id
       WHERE l.user_id IN (
         SELECT CASE WHEN f.user_id = $1 THEN f.friend_id ELSE f.user_id END
         FROM friendships f
         WHERE (f.user_id = $1 OR f.friend_id = $1) AND f.status = 'accepted'
       ) OR l.user_id = $1
       ORDER BY l.season_pts DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch friends leaderboard.' } });
  }
});

module.exports = router;
