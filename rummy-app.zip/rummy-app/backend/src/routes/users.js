const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const { validate, updateProfileSchema } = require('../middleware/validate');
const logger = require('../config/logger');

const router = Router();

// ─── Get Public Profile ──────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT u.id, u.username, u.display_name, u.avatar_url, u.vip_level,
              l.games_played, l.games_won, l.best_streak, l.rank_tier, l.season_pts
       FROM users u
       LEFT JOIN leaderboard l ON l.user_id = u.id
       WHERE u.id = $1 AND u.is_banned = FALSE`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'User not found.' } });
    res.json(rows[0]);
  } catch (err) {
    logger.error('Get user error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch user.' } });
  }
});

// ─── Update Profile ──────────────────────────────────────
router.patch('/me', authMiddleware, validate(updateProfileSchema), async (req, res) => {
  try {
    const fields = [];
    const values = [];
    let idx = 1;

    if (req.validated.display_name !== undefined) {
      fields.push(`display_name = $${idx++}`);
      values.push(req.validated.display_name);
    }
    if (req.validated.avatar_url !== undefined) {
      fields.push(`avatar_url = $${idx++}`);
      values.push(req.validated.avatar_url);
    }
    if (req.validated.preferences !== undefined) {
      fields.push(`preferences = $${idx++}`);
      values.push(JSON.stringify(req.validated.preferences));
    }

    if (fields.length === 0) {
      return res.status(400).json({ error: { code: 'NO_CHANGES', message: 'Nothing to update.' } });
    }

    values.push(req.user.id);
    await db.query(
      `UPDATE users SET ${fields.join(', ')} WHERE id = $${idx}`,
      values
    );

    res.json({ success: true });
  } catch (err) {
    logger.error('Update profile error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Profile update failed.' } });
  }
});

// ─── Get Own Stats ───────────────────────────────────────
router.get('/me/stats', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT games_played, games_won,
              CASE WHEN games_played > 0 THEN ROUND(100.0 * games_won / games_played, 1) ELSE 0 END AS win_rate,
              highest_score, best_streak, rank_tier, season_pts, total_points
       FROM leaderboard WHERE user_id = $1`,
      [req.user.id]
    );
    res.json(rows[0] || {});
  } catch (err) {
    logger.error('Get stats error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch stats.' } });
  }
});

// ─── Search Users ────────────────────────────────────────
router.get('/search', authMiddleware, async (req, res) => {
  try {
    const { q, limit = 20 } = req.query;
    if (!q || q.length < 2) return res.json([]);

    const { rows } = await db.query(
      `SELECT id, username, display_name, avatar_url, vip_level
       FROM users
       WHERE (username ILIKE $1 OR display_name ILIKE $1)
         AND is_banned = FALSE AND id != $2
       LIMIT $3`,
      [`%${q}%`, req.user.id, parseInt(limit)]
    );
    res.json(rows);
  } catch (err) {
    logger.error('Search users error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Search failed.' } });
  }
});

module.exports = router;
