const { Router } = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { signAccessToken, signRefreshToken, verifyToken, authMiddleware } = require('../middleware/auth');
const { validate, registerSchema, loginSchema } = require('../middleware/validate');
const { authLimiter } = require('../middleware/rateLimiter');
const logger = require('../config/logger');

const router = Router();

// ─── Register ────────────────────────────────────────────
router.post('/register', authLimiter, validate(registerSchema), async (req, res) => {
  try {
    const { username, email, password, phone, display_name } = req.validated;

    // Check existing
    const existing = await db.query(
      'SELECT id FROM users WHERE username = $1 OR email = $2',
      [username.toLowerCase(), email.toLowerCase()]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({
        error: { code: 'DUPLICATE_USER', message: 'Username or email already taken.' }
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const { rows } = await db.query(
      `INSERT INTO users (username, email, phone, password_hash, display_name, chips_balance)
       VALUES ($1,$2,$3,$4,$5,25000)
       RETURNING id, username, email, display_name, avatar_url, chips_balance, vip_level, xp_points, created_at`,
      [username.toLowerCase(), email.toLowerCase(), phone, passwordHash, display_name || username]
    );

    const user = rows[0];
    const accessToken = signAccessToken(user);
    const refreshToken = uuidv4();

    await db.query(
      'INSERT INTO auth_sessions (user_id, refresh_token, device_info, ip_address, expires_at) VALUES ($1,$2,$3,$4,NOW() + INTERVAL \'30 days\')',
      [user.id, refreshToken, JSON.stringify(req.validated.device_info || {}), req.ip]
    );

    logger.info(`User registered: ${username}`);

    res.status(201).json({
      user,
      tokens: { access: accessToken, refresh: refreshToken },
    });
  } catch (err) {
    logger.error('Register error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Registration failed.' } });
  }
});

// ─── Login ────────────────────────────────────────────────
router.post('/login', authLimiter, validate(loginSchema), async (req, res) => {
  try {
    const { login, password, device_info } = req.validated;

    const { rows } = await db.query(
      'SELECT * FROM users WHERE username = $1 OR email = $1',
      [login.toLowerCase()]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: { code: 'INVALID_CREDENTIALS', message: 'Invalid login credentials.' } });
    }

    const user = rows[0];

    if (user.is_banned) {
      return res.status(403).json({ error: { code: 'BANNED', message: `Account suspended: ${user.ban_reason}` } });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: { code: 'INVALID_CREDENTIALS', message: 'Invalid login credentials.' } });
    }

    const accessToken = signAccessToken(user);
    const refreshToken = uuidv4();

    await db.query(
      'INSERT INTO auth_sessions (user_id, refresh_token, device_info, ip_address, expires_at) VALUES ($1,$2,$3,$4,NOW() + INTERVAL \'30 days\')',
      [user.id, refreshToken, JSON.stringify(device_info || {}), req.ip]
    );

    await db.query(
      "UPDATE users SET status = 'online', last_seen = NOW() WHERE id = $1",
      [user.id]
    );

    logger.info(`User logged in: ${user.username}`);

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        display_name: user.display_name,
        avatar_url: user.avatar_url,
        chips_balance: user.chips_balance,
        vip_level: user.vip_level,
        xp_points: user.xp_points,
        preferences: user.preferences,
        created_at: user.created_at,
      },
      tokens: { access: accessToken, refresh: refreshToken },
    });
  } catch (err) {
    logger.error('Login error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Login failed.' } });
  }
});

// ─── Refresh Token ────────────────────────────────────────
router.post('/refresh', async (req, res) => {
  try {
    const { refresh_token } = req.body;
    if (!refresh_token) {
      return res.status(400).json({ error: { code: 'MISSING_TOKEN', message: 'Refresh token required.' } });
    }

    const { rows } = await db.query(
      'SELECT * FROM auth_sessions WHERE refresh_token = $1 AND expires_at > NOW()',
      [refresh_token]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: { code: 'INVALID_TOKEN', message: 'Invalid or expired refresh token.' } });
    }

    const session = rows[0];
    const { rows: userRows } = await db.query('SELECT * FROM users WHERE id = $1', [session.user_id]);
    if (!userRows.length) {
      return res.status(401).json({ error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
    }

    const user = userRows[0];
    const newAccessToken = signAccessToken(user);
    const newRefreshToken = uuidv4();

    // Rotate refresh token
    await db.query('DELETE FROM auth_sessions WHERE id = $1', [session.id]);
    await db.query(
      'INSERT INTO auth_sessions (user_id, refresh_token, device_info, ip_address, expires_at) VALUES ($1,$2,$3,$4,NOW() + INTERVAL \'30 days\')',
      [user.id, newRefreshToken, session.device_info, req.ip]
    );

    res.json({
      tokens: { access: newAccessToken, refresh: newRefreshToken },
    });
  } catch (err) {
    logger.error('Refresh error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Token refresh failed.' } });
  }
});

// ─── Logout ───────────────────────────────────────────────
router.post('/logout', async (req, res) => {
  try {
    const { refresh_token } = req.body;
    if (refresh_token) {
      await db.query('DELETE FROM auth_sessions WHERE refresh_token = $1', [refresh_token]);
    }
    res.status(204).send();
  } catch (err) {
    logger.error('Logout error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Logout failed.' } });
  }
});

// ─── Get Current User ────────────────────────────────────
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT id, username, email, phone, display_name, avatar_url, country, language, chips_balance, vip_level, xp_points, status, preferences, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'User not found.' } });
    }
    res.json(rows[0]);
  } catch (err) {
    logger.error('Get me error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch profile.' } });
  }
});

module.exports = router;
