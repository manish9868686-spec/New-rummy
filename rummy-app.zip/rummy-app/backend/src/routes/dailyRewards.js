const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../config/logger');

const router = Router();

// ─── Reward Status ──────────────────────────────────────
router.get('/status', authMiddleware, async (req, res) => {
  try {
    // Get current streak
    const { rows } = await db.query(
      `SELECT claimed_at FROM daily_rewards
       WHERE user_id = $1
       ORDER BY claimed_at DESC
       LIMIT 7`,
      [req.user.id]
    );

    // Calculate streak
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; i < 7; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      const dateStr = checkDate.toISOString().split('T')[0];
      if (rows.some(r => r.claimed_at.toISOString().split('T')[0] === dateStr)) {
        streak++;
      } else if (i === 0) {
        // Today not claimed — check if we can still claim
      } else {
        break;
      }
    }

    // Check if already claimed today
    const todayStr = today.toISOString().split('T')[0];
    const claimedToday = rows.length > 0 && rows[0].claimed_at.toISOString().split('T')[0] === todayStr;

    // Reward amounts
    const rewards = [500, 700, 1000, 1500, 2000, 3000, 5000]; // Day 1-7 rewards
    const nextReward = claimedToday ? null : rewards[Math.min(streak, 6)];

    res.json({
      streak: claimedToday ? streak : Math.max(0, streak - (rows.length > 0 ? (new Date() - rows[0].claimed_at > 86400000 ? 1 : 0) : 0)),
      claimed_today: claimedToday,
      next_reward: nextReward,
      rewards,
    });
  } catch (err) {
    logger.error('Daily reward status error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to get status.' } });
  }
});

// ─── Claim Daily Reward ──────────────────────────────────
router.post('/claim', authMiddleware, async (req, res) => {
  try {
    // Check already claimed today
    const today = new Date().toISOString().split('T')[0];
    const existing = await db.query(
      'SELECT id FROM daily_rewards WHERE user_id = $1 AND claimed_at = $2',
      [req.user.id, today]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: { code: 'ALREADY_CLAIMED', message: 'Already claimed today.' } });
    }

    // Calculate streak
    const { rows } = await db.query(
      'SELECT claimed_at FROM daily_rewards WHERE user_id = $1 ORDER BY claimed_at DESC LIMIT 1',
      [req.user.id]
    );

    let streak = 1;
    if (rows.length > 0) {
      const lastClaim = new Date(rows[0].claimed_at);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      if (lastClaim.toISOString().split('T')[0] === yesterday.toISOString().split('T')[0]) {
        // Consecutive
        const prevStreaks = await db.query(
          'SELECT COUNT(*) as cnt FROM daily_rewards WHERE user_id = $1 ORDER BY claimed_at DESC LIMIT 7',
          [req.user.id]
        );
        // Just use the day_streak of the previous row
        streak = Math.min((parseInt(rows[0].day_streak) || 0) + 1, 7);
      }
    }

    const rewards = [500, 700, 1000, 1500, 2000, 3000, 5000];
    const reward = rewards[Math.min(streak - 1, 6)];

    await db.query(
      'INSERT INTO daily_rewards (user_id, day_streak, reward_chips, claimed_at) VALUES ($1,$2,$3,$4)',
      [req.user.id, streak, reward, today]
    );

    await db.query(
      'UPDATE users SET chips_balance = chips_balance + $1 WHERE id = $2',
      [reward, req.user.id]
    );

    res.json({ success: true, streak, reward, day: streak });
  } catch (err) {
    logger.error('Claim daily reward error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Claim failed.' } });
  }
});

module.exports = router;
