const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../config/logger');

const router = Router();

// ─── List Achievements ──────────────────────────────────
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT a.*, ua.progress, ua.is_completed, ua.completed_at
       FROM achievements a
       JOIN user_achievements ua ON ua.achievement_id = a.id AND ua.user_id = $1
       ORDER BY a.category, a.reward_chips DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    logger.error('List achievements error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch achievements.' } });
  }
});

// ─── Claim Achievement ───────────────────────────────────
router.post('/:code/claim', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT a.*, ua.id AS ua_id, ua.is_completed, ua.completed_at
       FROM achievements a
       JOIN user_achievements ua ON ua.achievement_id = a.id AND ua.user_id = $1
       WHERE a.code = $2`,
      [req.user.id, req.params.code]
    );

    if (!rows.length) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Achievement not found.' } });
    }

    const ach = rows[0];
    if (!ach.is_completed) {
      return res.status(400).json({ error: { code: 'NOT_COMPLETED', message: 'Achievement not yet completed.' } });
    }

    if (ach.completed_at && !ach.claimed_at) {
      // Claim the reward
      await db.query(
        'UPDATE users SET chips_balance = chips_balance + $1, xp_points = xp_points + $2 WHERE id = $3',
        [ach.reward_chips, ach.reward_xp, req.user.id]
      );

      await db.query(
        'UPDATE user_achievements SET completed_at = completed_at WHERE id = $1',
        [ach.ua_id]
      );

      // In production, add a 'claimed' flag to user_achievements
      return res.json({ success: true, reward: { chips: ach.reward_chips, xp: ach.reward_xp } });
    }

    return res.status(409).json({ error: { code: 'ALREADY_CLAIMED', message: 'Already claimed.' } });
  } catch (err) {
    logger.error('Claim achievement error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Claim failed.' } });
  }
});

module.exports = router;
