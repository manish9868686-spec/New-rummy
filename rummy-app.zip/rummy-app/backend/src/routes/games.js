const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const logger = require('../config/logger');

const router = Router();

// ─── Game History ───────────────────────────────────────
router.get('/history', authMiddleware, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;

    const { rows } = await db.query(
      `SELECT gr.table_id, gr.final_score, gr.chips_won, gr.rank, gr.finished_at,
              t.variant, t.table_type, t.table_code
       FROM game_results gr
       JOIN game_tables t ON t.id = gr.table_id
       WHERE gr.user_id = $1
       ORDER BY gr.finished_at DESC
       LIMIT $2 OFFSET $3`,
      [req.user.id, parseInt(limit), (parseInt(page) - 1) * parseInt(limit)]
    );

    // Get player info for each game
    const games = await Promise.all(rows.map(async (game) => {
      const { rows: players } = await db.query(
        `SELECT gr2.user_id, gr2.rank, gr2.final_score,
                u.username, u.display_name, u.avatar_url
         FROM game_results gr2
         JOIN users u ON u.id = gr2.user_id
         WHERE gr2.table_id = $1
         ORDER BY gr2.rank`,
        [game.table_id]
      );
      return { ...game, players };
    }));

    res.json({ games, page: parseInt(page) });
  } catch (err) {
    logger.error('Game history error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch history.' } });
  }
});

// ─── Game Replay ────────────────────────────────────────
router.get('/:id/replay', authMiddleware, async (req, res) => {
  try {
    const tableId = req.params.id;

    // Verify user participated
    const participated = await db.query(
      'SELECT id FROM game_results WHERE table_id = $1 AND user_id = $2',
      [tableId, req.user.id]
    );
    if (!participated.rows.length) {
      return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Not a participant.' } });
    }

    // Get rounds
    const { rows: rounds } = await db.query(
      'SELECT * FROM game_rounds WHERE table_id = $1 ORDER BY round_number',
      [tableId]
    );

    // Get actions for each round
    const roundsWithActions = await Promise.all(rounds.map(async (round) => {
      const { rows: actions } = await db.query(
        `SELECT ga.seat_index, ga.action_type, ga.card_code, ga.timestamp,
                u.username
         FROM game_actions ga
         JOIN users u ON u.id = ga.user_id
         WHERE ga.round_id = $1
         ORDER BY ga.timestamp`,
        [round.id]
      );

      const { rows: hands } = await db.query(
        `SELECT rh.user_id, rh.initial_hand, rh.final_hand, rh.points, rh.is_declared,
                u.username
         FROM round_hands rh
         JOIN users u ON u.id = rh.user_id
         WHERE rh.round_id = $1`,
        [round.id]
      );

      return { ...round, actions, hands };
    }));

    res.json({ rounds: roundsWithActions });
  } catch (err) {
    logger.error('Game replay error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch replay.' } });
  }
});

// ─── Transactions ────────────────────────────────────────
router.get('/transactions', authMiddleware, async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;
    const conditions = ['user_id = $1'];
    const values = [req.user.id];
    let idx = 2;

    if (type) {
      conditions.push(`tx_type = $${idx++}`);
      values.push(type);
    }

    const { rows } = await db.query(
      `SELECT * FROM transactions
       WHERE ${conditions.join(' AND ')}
       ORDER BY created_at DESC
       LIMIT $${idx} OFFSET $${idx + 1}`,
      [...values, parseInt(limit), (parseInt(page) - 1) * parseInt(limit)]
    );

    res.json({ transactions: rows, page: parseInt(page) });
  } catch (err) {
    logger.error('Transactions error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch transactions.' } });
  }
});

// ─── Balance ─────────────────────────────────────────────
router.get('/balance', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT chips_balance FROM users WHERE id = $1',
      [req.user.id]
    );
    res.json({ balance: rows[0].chips_balance });
  } catch (err) {
    logger.error('Balance error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch balance.' } });
  }
});

module.exports = router;
