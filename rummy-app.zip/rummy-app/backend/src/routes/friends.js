const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const { sendPushNotification } = require('../services/notifications');
const logger = require('../config/logger');

const router = Router();

// ─── List Friends ─────────────────────────────────────────
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT f.id AS friendship_id, f.status, f.created_at,
              u.id, u.username, u.display_name, u.avatar_url, u.vip_level, u.status
       FROM friendships f
       JOIN users u ON (CASE WHEN f.user_id = $1 THEN f.friend_id ELSE f.user_id END) = u.id
       WHERE (f.user_id = $1 OR f.friend_id = $1) AND f.status = 'accepted'
       ORDER BY u.display_name`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    logger.error('List friends error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch friends.' } });
  }
});

// ─── Friend Requests ─────────────────────────────────────
router.get('/requests', authMiddleware, async (req, res) => {
  try {
    // Incoming
    const { rows: incoming } = await db.query(
      `SELECT f.id AS friendship_id, f.created_at,
              u.id, u.username, u.display_name, u.avatar_url
       FROM friendships f
       JOIN users u ON f.user_id = u.id
       WHERE f.friend_id = $1 AND f.status = 'pending'`,
      [req.user.id]
    );

    // Outgoing
    const { rows: outgoing } = await db.query(
      `SELECT f.id AS friendship_id, f.created_at,
              u.id, u.username, u.display_name, u.avatar_url
       FROM friendships f
       JOIN users u ON f.friend_id = u.id
       WHERE f.user_id = $1 AND f.status = 'pending'`,
      [req.user.id]
    );

    res.json({ incoming, outgoing });
  } catch (err) {
    logger.error('Friend requests error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch requests.' } });
  }
});

// ─── Send Friend Request ─────────────────────────────────
router.post('/request', authMiddleware, async (req, res) => {
  try {
    const { friend_id } = req.body;
    if (!friend_id || friend_id === req.user.id) {
      return res.status(400).json({ error: { code: 'INVALID', message: 'Invalid friend ID.' } });
    }

    // Check existing
    const existing = await db.query(
      `SELECT id, status FROM friendships
       WHERE (user_id = $1 AND friend_id = $2) OR (user_id = $2 AND friend_id = $1)`,
      [req.user.id, friend_id]
    );

    if (existing.rows.length > 0) {
      const rel = existing.rows[0];
      if (rel.status === 'accepted') {
        return res.status(409).json({ error: { code: 'ALREADY_FRIENDS', message: 'Already friends.' } });
      }
      if (rel.status === 'pending') {
        return res.status(409).json({ error: { code: 'REQUEST_PENDING', message: 'Friend request already pending.' } });
      }
      if (rel.status === 'blocked') {
        return res.status(403).json({ error: { code: 'BLOCKED', message: 'Cannot send request.' } });
      }
    }

    await db.query(
      'INSERT INTO friendships (user_id, friend_id, status) VALUES ($1,$2,\'pending\')',
      [req.user.id, friend_id]
    );

    // Notify
    await sendPushNotification(friend_id, 'Friend Request', `${req.user.username} sent you a friend request!`);

    res.status(201).json({ success: true });
  } catch (err) {
    logger.error('Friend request error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Request failed.' } });
  }
});

// ─── Accept ───────────────────────────────────────────────
router.patch('/:id/accept', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      "UPDATE friendships SET status = 'accepted' WHERE id = $1 AND friend_id = $2 AND status = 'pending' RETURNING user_id",
      [req.params.id, req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Request not found.' } });
    }
    await sendPushNotification(rows[0].user_id, 'Friend Request Accepted', `${req.user.username} accepted your friend request!`);
    res.json({ success: true });
  } catch (err) {
    logger.error('Accept friend error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to accept.' } });
  }
});

// ─── Reject / Cancel ─────────────────────────────────────
router.patch('/:id/reject', authMiddleware, async (req, res) => {
  try {
    await db.query(
      "DELETE FROM friendships WHERE id = $1 AND (user_id = $2 OR friend_id = $2) AND status = 'pending'",
      [req.params.id, req.user.id]
    );
    res.json({ success: true });
  } catch (err) {
    logger.error('Reject friend error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to reject.' } });
  }
});

// ─── Remove ───────────────────────────────────────────────
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    await db.query(
      "DELETE FROM friendships WHERE id = $1 AND (user_id = $2 OR friend_id = $2) AND status = 'accepted'",
      [req.params.id, req.user.id]
    );
    res.json({ success: true });
  } catch (err) {
    logger.error('Remove friend error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to remove friend.' } });
  }
});

module.exports = router;
