const redis = require('redis');

let client = null;
let isConnected = false;

async function connect() {
  if (!process.env.REDIS_URL) {
    console.warn('REDIS_URL not set, running without Redis.');
    return null;
  }
  client = redis.createClient({ url: process.env.REDIS_URL });
  client.on('error', (err) => console.error('Redis error:', err));
  client.on('connect', () => { isConnected = true; });
  await client.connect();
  return client;
}

function getClient() { return client; }
function isReady() { return isConnected; }

module.exports = { connect, getClient, isReady };
