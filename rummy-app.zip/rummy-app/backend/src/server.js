/**
 * Classic Indian Rummy — Server Entry Point
 *
 * Express + Socket.io server with PostgreSQL + Redis.
 */

require('dotenv').config();

const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const logger = require('./config/logger');
const { generalLimiter } = require('./middleware/rateLimiter');
const { initSocketServer } = require('./socket/gameSocket');

// ─── Express App ──────────────────────────────────────────
const app = express();

app.use(helmet());
app.use(compression());
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '1mb' }));
app.use(generalLimiter);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), uptime: process.uptime() });
});

// ─── API Routes ───────────────────────────────────────────
const api = express.Router();

api.use('/auth', require('./routes/auth'));
api.use('/users', require('./routes/users'));
api.use('/friends', require('./routes/friends'));
api.use('/tables', require('./routes/tables'));
api.use('/leaderboard', require('./routes/leaderboard'));
api.use('/achievements', require('./routes/achievements'));
api.use('/daily-rewards', require('./routes/dailyRewards'));
api.use('/games', require('./routes/games'));
api.use('/transactions', require('./routes/games')); // transactions on /games/transactions

app.use('/api/v1', api);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: `Route ${req.method} ${req.path} not found.` } });
});

// Global error handler
app.use((err, req, res, _next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'An unexpected error occurred.' } });
});

// ─── HTTP + Socket.io Server ──────────────────────────────
const server = http.createServer(app);

const io = initSocketServer(server);

// ─── Redis (optional) ─────────────────────────────────────
const redis = require('./config/redis');
redis.connect().then(() => {
  logger.info('Redis connected');
}).catch((err) => {
  logger.warn('Redis not available, continuing without:', err.message);
});

// ─── Start ────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  logger.info(`🃏 Classic Indian Rummy server running on port ${PORT}`);
  logger.info(`   REST API: http://localhost:${PORT}/api/v1`);
  logger.info(`   WebSocket: ws://localhost:${PORT}`);
  logger.info(`   Environment: ${process.env.NODE_ENV || 'development'}`);
});

// ─── Graceful Shutdown ────────────────────────────────────
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

async function shutdown() {
  logger.info('Shutting down gracefully...');

  // Close socket connections
  io.close();

  // Close HTTP server
  server.close();

  // Close database pool
  const db = require('./config/database');
  await db.pool.end();

  // Close Redis
  const redisClient = redis.getClient();
  if (redisClient) await redisClient.quit();

  logger.info('Shutdown complete.');
  process.exit(0);
}

module.exports = { app, server, io };
