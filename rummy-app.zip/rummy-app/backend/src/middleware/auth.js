const jwt = require('jsonwebtoken');
const db = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const ACCESS_EXPIRY = process.env.JWT_ACCESS_EXPIRY || '15m';
const REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRY || '30d';

function signAccessToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, vip: user.vip_level },
    JWT_SECRET,
    { expiresIn: ACCESS_EXPIRY }
  );
}

function signRefreshToken(userId) {
  return jwt.sign(
    { sub: userId, type: 'refresh' },
    JWT_SECRET,
    { expiresIn: REFRESH_EXPIRY }
  );
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

/**
 * Express middleware — requires valid access token.
 */
async function authMiddleware(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Authorization header required.' } });
    }

    const token = header.split(' ')[1];
    const payload = verifyToken(token);

    // Optional: check user still exists / not banned
    const { rows } = await db.query('SELECT id, username, is_banned FROM users WHERE id = $1', [payload.sub]);
    if (rows.length === 0) {
      return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'User not found.' } });
    }
    if (rows[0].is_banned) {
      return res.status(403).json({ error: { code: 'BANNED', message: 'Account suspended.' } });
    }

    req.user = { id: payload.sub, username: payload.username, vip_level: payload.vip };
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: { code: 'TOKEN_EXPIRED', message: 'Access token expired.' } });
    }
    return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Invalid token.' } });
  }
}

/**
 * Socket.io middleware — authenticates via token query param.
 */
async function socketAuthMiddleware(socket, next) {
  try {
    const token = socket.handshake.query.token;
    if (!token) return next(new Error('AUTH_REQUIRED'));

    const payload = verifyToken(token);
    const { rows } = await db.query('SELECT id, username, is_banned FROM users WHERE id = $1', [payload.sub]);
    if (!rows[0] || rows[0].is_banned) return next(new Error('BANNED'));

    socket.userId = payload.sub;
    socket.username = payload.username;
    next();
  } catch {
    next(new Error('AUTH_REQUIRED'));
  }
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyToken,
  authMiddleware,
  socketAuthMiddleware,
};
