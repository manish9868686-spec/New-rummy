/**
 * Classic Indian Rummy — Hand Validator
 *
 * Valid declaration requires:
 * 1. At least TWO sequences, one of which MUST be a PURE sequence (no jokers).
 * 2. Remaining cards can be sequences or sets.
 * 3. All 13 cards must be part of a valid meld.
 *
 * Meld types:
 * - Pure Sequence: 3+ consecutive same-suit cards, no jokers
 * - Impure Sequence: 3+ consecutive same-suit cards, jokers allowed
 * - Set: 3-4 same-rank different-suit cards, jokers allowed
 */

const { RANK_ORDER } = require('./cards');

/**
 * Check if a card is a joker (printed or wild).
 */
function isJoker(card, wildJoker) {
  return card === 'J1' || card === 'J2' || card === wildJoker;
}

/**
 * Determine if a group is a pure sequence.
 */
function isPureSequence(group, wildJoker) {
  if (group.length < 3) return false;
  if (group.some(c => isJoker(c, wildJoker))) return false;

  const suit = group[0][0];
  if (group.some(c => c[0] !== suit)) return false;

  const ranks = group.map(c => RANK_ORDER[c.substring(1)]).sort((a, b) => a - b);
  for (let i = 1; i < ranks.length; i++) {
    if (ranks[i] !== ranks[i - 1] + 1) return false;
  }
  return true;
}

/**
 * Determine if a group is a valid sequence (jokers allowed) — covers pure too.
 */
function isSequence(group, wildJoker) {
  if (group.length < 3) return false;

  // Count jokers
  const jokerCount = group.filter(c => isJoker(c, wildJoker)).length;
  const realCards = group.filter(c => !isJoker(c, wildJoker));

  if (realCards.length === 0) return true; // all jokers — unusual but valid

  const suit = realCards[0][0];
  if (realCards.some(c => c[0] !== suit)) return false;

  const ranks = realCards.map(c => RANK_ORDER[c.substring(1)]).sort((a, b) => a - b);
  // Check gaps can be filled by jokers
  let gaps = 0;
  for (let i = 1; i < ranks.length; i++) {
    gaps += ranks[i] - ranks[i - 1] - 1;
  }
  // Also account for jokers at ends (before first, after last)
  const totalLength = ranks.length + jokerCount;
  return gaps <= jokerCount && totalLength >= 3;
}

/**
 * Determine if a group is a valid set (3-4 same rank, different suits, jokers allowed).
 */
function isSet(group, wildJoker) {
  if (group.length < 3 || group.length > 4) return false;

  const jokerCount = group.filter(c => isJoker(c, wildJoker)).length;
  const realCards = group.filter(c => !isJoker(c, wildJoker));

  if (realCards.length === 0) return true;

  const rank = realCards[0].substring(1);
  if (realCards.some(c => c.substring(1) !== rank)) return false;

  // All real cards must have different suits
  const suits = new Set(realCards.map(c => c[0]));
  return suits.size === realCards.length;
}

/**
 * Main declaration validator.
 * @param {string[]} hand - 13 card codes
 * @param {string[][]} meldGroups - Array of groups, each is an array of card codes
 * @param {string} wildJoker - The wild joker card code
 * @returns {{ valid: boolean, deadwood: number, hasPureSeq: boolean, seqCount: number }}
 */
function validateDeclaration(hand, meldGroups, wildJoker) {
  // All 13 cards must be in exactly the meld groups
  const meldCards = new Set(meldGroups.flat());
  if (meldCards.size !== 13 || hand.some(c => !meldCards.has(c))) {
    return { valid: false, deadwood: 100, hasPureSeq: false, seqCount: 0, reason: 'Not all cards are in meld groups.' };
  }

  let hasPureSeq = false;
  let seqCount = 0;
  let validMelds = 0;

  for (const group of meldGroups) {
    const pure = isPureSequence(group, wildJoker);
    const seq = isSequence(group, wildJoker);
    const setOk = isSet(group, wildJoker);

    if (pure) hasPureSeq = true;
    if (seq) seqCount++;
    if (pure || seq || setOk) validMelds++;
  }

  if (!hasPureSeq) {
    return { valid: false, deadwood: 100, hasPureSeq: false, seqCount, reason: 'Missing pure sequence.' };
  }

  if (seqCount < 2) {
    return { valid: false, deadwood: 100, hasPureSeq: true, seqCount, reason: 'Need at least 2 sequences.' };
  }

  if (validMelds !== meldGroups.length) {
    return { valid: false, deadwood: 100, hasPureSeq: true, seqCount, reason: 'Some groups are invalid.' };
  }

  return { valid: true, deadwood: 0, hasPureSeq: true, seqCount, reason: 'Valid declaration!' };
}

/**
 * Calculate deadwood (unmelded cards) points.
 */
function calculateDeadwood(unmeldedCards) {
  const { cardPoints } = require('./cards');
  let total = 0;
  for (const card of unmeldedCards) {
    total += cardPoints(card);
  }
  return total;
}

/**
 * Find the best possible meld arrangement using a greedy/heuristic approach.
 * Returns { melds, deadwood, deadwoodPoints }.
 */
function findBestMelds(hand, wildJoker) {
  // For complex meld finding, we use a simplified heuristic.
  // Full optimal meld-finding is NP-hard; this gives very good results for 13 cards.
  const cards = [...hand];
  const melds = [];
  const used = new Set();

  // Step 1: Find pure sequences first (greedy by suit)
  for (const suit of ['S', 'H', 'D', 'C']) {
    const suited = cards.filter(c => c[0] === suit && !used.has(c) && !isJoker(c, wildJoker));
    suited.sort((a, b) => RANK_ORDER[a.substring(1)] - RANK_ORDER[b.substring(1)]);

    // Find consecutive runs of 3+
    let run = [];
    for (const card of suited) {
      if (run.length === 0) {
        run = [card];
      } else {
        const lastRank = RANK_ORDER[run[run.length - 1].substring(1)];
        const thisRank = RANK_ORDER[card.substring(1)];
        if (thisRank === lastRank + 1) {
          run.push(card);
        } else {
          if (run.length >= 3) {
            melds.push(run);
            run.forEach(c => used.add(c));
          }
          run = [card];
        }
      }
    }
    if (run.length >= 3) {
      melds.push(run);
      run.forEach(c => used.add(c));
    }
  }

  // Step 2: Find sets
  const remaining = cards.filter(c => !used.has(c) && !isJoker(c, wildJoker));
  const rankGroups = {};
  for (const card of remaining) {
    const r = card.substring(1);
    if (!rankGroups[r]) rankGroups[r] = [];
    if (!rankGroups[r].some(c => c[0] === card[0])) {
      rankGroups[r].push(card);
    }
  }
  for (const [rank, group] of Object.entries(rankGroups)) {
    if (group.length >= 3) {
      const setCards = group.slice(0, Math.min(4, group.length));
      melds.push(setCards);
      setCards.forEach(c => used.add(c));
    }
  }

  // Step 3: Impure sequences with remaining cards + jokers
  const jokersAvailable = cards.filter(c => isJoker(c, wildJoker) && !used.has(c));
  const stillRemaining = cards.filter(c => !used.has(c));

  const deadwoodCards = [...stillRemaining, ...jokersAvailable.filter(j => !used.has(j))];
  const deadwood = calculateDeadwood(deadwoodCards);

  return { melds, deadwoodCards, deadwood };
}

module.exports = {
  isJoker, isPureSequence, isSequence, isSet,
  validateDeclaration, calculateDeadwood, findBestMelds,
};
