# 🃏 Classic Rummy — Build & Release Guide

This guide walks you through publishing the project to GitHub, letting GitHub Actions build a signed **APK** and **AAB** automatically, and downloading the artifacts.

> **App name:** Classic Rummy
> **Package id:** `com.rummyapp.classicrummy`
> **React Native:** 0.73.2 · **Min SDK:** 23 · **Target SDK:** 34

---

## 📦 What's in this scaffold

```
rummy-app/
├── .github/workflows/android.yml   ← CI: builds APK + AAB on every push
├── backend/                         ← Node + Express + Socket.io API server
├── database/schema.sql              ← PostgreSQL schema
├── docs/                            ← API + deployment docs
└── frontend/                        ← React Native 0.73 app
    ├── android/                     ← Native Android project (Gradle)
    │   ├── app/
    │   │   ├── build.gradle
    │   │   ├── debug.keystore       ← Default signing key for CI
    │   │   ├── proguard-rules.pro
    │   │   └── src/main/
    │   │       ├── AndroidManifest.xml
    │   │       ├── java/com/rummyapp/classicrummy/
    │   │       │   ├── MainActivity.kt
    │   │       │   └── MainApplication.kt
    │   │       └── res/             ← Icons, strings, colors, themes
    │   ├── build.gradle             ← Root Gradle config
    │   ├── settings.gradle
    │   ├── gradle.properties
    │   ├── gradle/wrapper/          ← Gradle wrapper jar + properties
    │   ├── gradlew                  ← Unix build script
    │   └── gradlew.bat              ← Windows build script
    ├── ios/                         ← Native iOS project (Xcode + CocoaPods)
    ├── src/                         ← App JS/TS code (screens, components, …)
    ├── assets/                      ← Fonts, images, sounds
    ├── index.js                     ← RN entry point
    ├── app.json                     ← App registration
    ├── babel.config.js
    ├── metro.config.js
    ├── package.json
    └── react-native.config.js
```

---

## 🚀 Part 1 — Push the project to GitHub

### 1. Install Git (if you haven't)
- macOS: `brew install git` (or use Xcode Command Line Tools)
- Windows: download from [git-scm.com](https://git-scm.com/)
- Linux: `sudo apt install git` (or your distro's package manager)

### 2. Create an empty repository on GitHub
1. Go to <https://github.com/new>
2. **Repository name:** `classic-rummy` (or whatever you like)
3. Set **Public** or **Private** — both work with Actions on free tier
4. **Do NOT** initialize with a README, .gitignore, or license — we already have those
5. Click **Create repository**

### 3. Download this scaffold to your local machine
Copy the entire `rummy-app/` directory from your Zaro workspace to a local folder:

```bash
# If you exported the workspace as a zip, unzip it; otherwise
# however you got the files locally, place them so you have:
~/projects/classic-rummy/
├── .github/
├── backend/
├── database/
├── docs/
├── frontend/
└── README.md (this file)
```

### 4. Initialize Git and push
Open a terminal in the project root (the folder that contains `frontend/`) and run:

```bash
cd ~/projects/classic-rummy

# Initialize repo
git init -b main

# Stage everything (the included .gitignore will skip node_modules, build/, etc.)
git add .

# First commit
git commit -m "Initial commit: Classic Rummy full-stack project"

# Connect to your GitHub repo (replace <your-username> and the repo name)
git remote add origin https://github.com/<your-username>/classic-rummy.git

# Push
git push -u origin main
```

> 💡 If `git push` asks for a password, GitHub no longer accepts account passwords over HTTPS. Generate a **Personal Access Token** at <https://github.com/settings/tokens> (scope: `repo`) and paste it as the password. Or set up SSH keys at <https://github.com/settings/keys>.

---

## 🤖 Part 2 — Watch GitHub Actions build your APK

The workflow at `.github/workflows/android.yml` runs automatically on every push to `main` (or `master`), on every pull request, and whenever you push a tag like `v1.0.0`. You can also trigger it manually.

### Watch the build live
1. Open your repo on GitHub
2. Click the **Actions** tab
3. You'll see a run titled **"Android Build"** — click into it
4. Click the **build** job to expand the steps; you can watch each Gradle task stream live

A clean first build takes **~10–15 minutes** because GitHub has to download the Android SDK, Gradle, and ~600 MB of npm dependencies. Subsequent builds are faster thanks to npm caching.

### Trigger a build manually
1. **Actions** tab → **Android Build** workflow → **Run workflow** button → pick a branch → **Run workflow**

---

## 📲 Part 3 — Download the APK / AAB

Once the workflow finishes (you'll see a green ✅ next to the run):

1. Open the completed run from the **Actions** tab
2. Scroll to the **Artifacts** section at the bottom of the run summary
3. You'll see two artifacts:
   - **`ClassicRummy-release-apk`** — the APK you can sideload onto an Android device
   - **`ClassicRummy-release-aab`** — the App Bundle for uploading to Google Play
4. Click either artifact to download a `.zip` containing the file

### Install the APK on a device

```bash
# Unzip the downloaded artifact
unzip ClassicRummy-release-apk.zip

# Plug in your Android device with USB debugging enabled
adb install app-release.apk
```

Or simply transfer `app-release.apk` to the device, open it in a file manager, and tap to install (you may need to enable "Install from unknown sources").

### Tagged releases (automatic GitHub Releases)
If you push a Git tag starting with `v` (e.g. `v1.0.0`), the workflow will **also** create a GitHub Release with the APK and AAB attached:

```bash
git tag v1.0.0
git push origin v1.0.0
```

Then visit the **Releases** section of your repo to download the artifacts directly — no need to dig through the Actions tab.

---

## 🔐 Part 4 — Production signing (when you're ready to ship to Play Store)

The included build is signed with the **debug keystore** that ships with React Native. That's fine for testing and sideloading, but Google Play requires a **real, private upload key** for AAB submissions.

### Generate a production keystore (one time)

```bash
keytool -genkeypair -v -storetype PKCS12 \
  -keystore classicrummy-upload-key.keystore \
  -alias classicrummy-upload \
  -keyalg RSA -keysize 2048 -validity 10000
```

Answer the prompts and remember the **store password** and **key password** — you'll need them again.

### Add the keystore to GitHub Secrets
1. Base64-encode the keystore (so it can live in a secret):
   ```bash
   base64 -i classicrummy-upload-key.keystore -o keystore.b64
   ```
2. On GitHub: **Settings → Secrets and variables → Actions → New repository secret**
3. Add four secrets:
   - `ANDROID_KEYSTORE_BASE64` — paste the contents of `keystore.b64`
   - `ANDROID_KEYSTORE_PASSWORD` — your store password
   - `ANDROID_KEY_ALIAS` — `classicrummy-upload`
   - `ANDROID_KEY_PASSWORD` — your key password

### Update the workflow to use the production key
Add a step before the Gradle build in `.github/workflows/android.yml`:

```yaml
- name: Decode upload keystore
  run: |
    echo "${{ secrets.ANDROID_KEYSTORE_BASE64 }}" | base64 -d > frontend/android/app/upload-key.keystore

- name: Build Release APK
  env:
    CLASSICRUMMY_UPLOAD_STORE_FILE: upload-key.keystore
    CLASSICRUMMY_UPLOAD_STORE_PASSWORD: ${{ secrets.ANDROID_KEYSTORE_PASSWORD }}
    CLASSICRUMMY_UPLOAD_KEY_ALIAS: ${{ secrets.ANDROID_KEY_ALIAS }}
    CLASSICRUMMY_UPLOAD_KEY_PASSWORD: ${{ secrets.ANDROID_KEY_PASSWORD }}
  run: cd frontend/android && ./gradlew assembleRelease --no-daemon
```

The `app/build.gradle` is already wired to read these env vars — when they're present, it uses your production key; when absent, it falls back to the debug keystore.

> ⚠️ **Never commit the keystore file or its passwords to Git.** The `.gitignore` already excludes `*.keystore` (except `debug.keystore`).

---

## 🛠️ Part 5 — Local development (optional)

You don't need a local setup just to get APKs — Actions handles it. But if you want to run the app on a device/simulator while developing:

### Prerequisites
- **Node.js 18+** (`nvm install 18 && nvm use 18`)
- **JDK 17** (Temurin or Zulu recommended)
- **Android Studio** with the Android SDK + emulator
- For iOS: **macOS** + **Xcode 15+** + **CocoaPods**

### Run on Android

```bash
cd frontend
npm install
npx react-native start          # Terminal 1: Metro bundler
npx react-native run-android    # Terminal 2: build & launch
```

### Run on iOS (Mac only)

```bash
cd frontend
npm install
cd ios && pod install && cd ..
npx react-native start
npx react-native run-ios
```

### Build a release APK locally

```bash
cd frontend/android
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk
```

---

## 🧰 Troubleshooting

| Symptom | Fix |
|---|---|
| `gradlew: Permission denied` in CI | The workflow runs `chmod +x android/gradlew` already; if running locally on Linux/macOS, run that command yourself once. |
| Gradle wrapper jar missing | Re-download from <https://github.com/gradle/gradle/raw/v8.3.0/gradle/wrapper/gradle-wrapper.jar> into `frontend/android/gradle/wrapper/`. |
| `SDK location not found` locally | Create `frontend/android/local.properties` with `sdk.dir=/path/to/Android/sdk` (CI auto-detects it). |
| `Could not find :react-native:` | Run `npm install` inside `frontend/` first; React Native Gradle plugin reads from `node_modules/`. |
| iOS pod install fails | Run `cd ios && pod repo update && pod install`. |
| `metro` cache weirdness | `npx react-native start --reset-cache`. |

---

## 📚 Project resources

- Full backend API reference: [`docs/api-reference.md`](docs/api-reference.md)
- Deployment & scaling guide: [`docs/deployment.md`](docs/deployment.md)
- Database schema: [`database/schema.sql`](database/schema.sql)

---

**Built with React Native 0.73 · Node 18 · PostgreSQL 15 · Socket.io 4**
