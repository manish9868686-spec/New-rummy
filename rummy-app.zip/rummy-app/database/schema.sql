-- ============================================================
-- CLASSIC INDIAN RUMMY — COMPLETE DATABASE SCHEMA
-- PostgreSQL 15+
-- ============================================================

-- ─── Extensions ───────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- ─── Enums ───────────────────────────────────────────────
CREATE TYPE user_status     AS ENUM ('online', 'offline', 'in_game', 'away');
CREATE TYPE game_status     AS ENUM ('waiting', 'in_progress', 'finished', 'cancelled');
CREATE TYPE table_type      AS ENUM ('public', 'private', 'tournament');
CREATE TYPE table_variant   AS ENUM ('points', 'deals', 'pool_101', 'pool_201');
CREATE TYPE turn_phase      AS ENUM ('draw', 'discard', 'declare', 'finished');
CREATE TYPE pack_type       AS ENUM ('starter', 'daily', 'tournament', 'promo');
CREATE TYPE achievement_cat AS ENUM ('games_played', 'games_won', 'streak', 'points', 'tournament', 'social', 'special');
CREATE TYPE friend_status   AS ENUM ('pending', 'accepted', 'blocked');
CREATE TYPE transaction_type AS ENUM ('deposit', 'withdraw', 'winning', 'entry_fee', 'refund', 'bonus');

-- ─── Users ───────────────────────────────────────────────
CREATE TABLE users (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username      CITEXT UNIQUE NOT NULL,
    email         CITEXT UNIQUE NOT NULL,
    phone         VARCHAR(15) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name  VARCHAR(60),
    avatar_url    TEXT,
    country       VARCHAR(3) DEFAULT 'IN',
    language      VARCHAR(5) DEFAULT 'en-IN',
    chips_balance BIGINT DEFAULT 25000 CHECK (chips_balance >= 0),
    vip_level     SMALLINT DEFAULT 0 CHECK (vip_level BETWEEN 0 AND 10),
    xp_points     BIGINT DEFAULT 0,
    status        user_status DEFAULT 'offline',
    last_seen     TIMESTAMPTZ DEFAULT NOW(),
    is_verified   BOOLEAN DEFAULT FALSE,
    is_banned     BOOLEAN DEFAULT FALSE,
    ban_reason    TEXT,
    device_tokens TEXT[],              -- FCM/APNs push tokens
    preferences   JSONB DEFAULT '{"theme":"system","sound":true,"vibration":true,"notify_game_invite":true,"notify_turn":true,"notify_chat":true}',
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_status  ON users(status);
CREATE INDEX idx_users_chips   ON users(chips_balance DESC);
CREATE INDEX idx_users_xp      ON users(xp_points DESC);
CREATE INDEX idx_users_country ON users(country);

-- ─── Auth Sessions ───────────────────────────────────────
CREATE TABLE auth_sessions (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token TEXT UNIQUE NOT NULL,
    device_info   JSONB DEFAULT '{}',
    ip_address    INET,
    expires_at    TIMESTAMPTZ NOT NULL,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_auth_sessions_user ON auth_sessions(user_id);

-- ─── Friends ─────────────────────────────────────────────
CREATE TABLE friendships (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    friend_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status      friend_status DEFAULT 'pending',
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, friend_id),
    CHECK(user_id <> friend_id)
);

CREATE INDEX idx_friends_user   ON friendships(user_id, status);
CREATE INDEX idx_friends_friend ON friendships(friend_id, status);

-- ─── Game Tables ─────────────────────────────────────────
CREATE TABLE game_tables (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_code       VARCHAR(8) UNIQUE NOT NULL,   -- 6-char join code
    table_type       table_type DEFAULT 'public',
    variant          table_variant NOT NULL,
    max_players      SMALLINT DEFAULT 6 CHECK (max_players BETWEEN 2 AND 6),
    entry_fee        BIGINT DEFAULT 0 CHECK (entry_fee >= 0),
    prize_pool       BIGINT DEFAULT 0,
    min_chips        BIGINT DEFAULT 0,
    turn_duration    INT DEFAULT 30,               -- seconds
    status           game_status DEFAULT 'waiting',
    winner_id        UUID REFERENCES users(id),
    created_by       UUID NOT NULL REFERENCES users(id),
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    started_at       TIMESTAMPTZ,
    finished_at      TIMESTAMPTZ
);

CREATE INDEX idx_tables_status ON game_tables(status);
CREATE INDEX idx_tables_type   ON game_tables(table_type, variant);

-- ─── Table Players (Seats) ───────────────────────────────
CREATE TABLE table_players (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_id    UUID NOT NULL REFERENCES game_tables(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id),
    seat_index  SMALLINT NOT NULL CHECK (seat_index BETWEEN 0 AND 5),
    joined_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(table_id, user_id),
    UNIQUE(table_id, seat_index)
);

CREATE INDEX idx_tp_table ON table_players(table_id);

-- ─── Game Rounds ─────────────────────────────────────────
CREATE TABLE game_rounds (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_id      UUID NOT NULL REFERENCES game_tables(id) ON DELETE CASCADE,
    round_number  INT NOT NULL,
    dealer_seat   SMALLINT NOT NULL,
    status        game_status DEFAULT 'in_progress',
    started_at    TIMESTAMPTZ DEFAULT NOW(),
    finished_at   TIMESTAMPTZ,
    UNIQUE(table_id, round_number)
);

-- ─── Round Hands (per player per round) ──────────────────
CREATE TABLE round_hands (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    round_id       UUID NOT NULL REFERENCES game_rounds(id) ON DELETE CASCADE,
    user_id        UUID NOT NULL REFERENCES users(id),
    initial_hand   JSONB NOT NULL,           -- ["H5","CJ","SA",...]
    final_hand     JSONB,                   -- hand at round end
    meld_groups    JSONB,                   -- [{type:"pure_seq",cards:[...]},...]
    points         INT DEFAULT 0,           -- deadwood points
    is_declared    BOOLEAN DEFAULT FALSE,
    is_valid       BOOLEAN,
    finished_at    TIMESTAMPTZ,
    UNIQUE(round_id, user_id)
);

-- ─── Game Actions Log ────────────────────────────────────
CREATE TABLE game_actions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    round_id    UUID NOT NULL REFERENCES game_rounds(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id),
    seat_index  SMALLINT NOT NULL,
    action_type VARCHAR(20) NOT NULL,       -- 'draw_pile','draw_discard','discard','declare','drop','reorder'
    card_code   VARCHAR(3),
    hand_state  JSONB,                     -- snapshot after action
    timestamp   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ga_round ON game_actions(round_id);

-- ─── Finished Games ──────────────────────────────────────
CREATE TABLE game_results (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_id    UUID NOT NULL REFERENCES game_tables(id),
    user_id     UUID NOT NULL REFERENCES users(id),
    final_score INT NOT NULL,
    chips_won   BIGINT DEFAULT 0,
    rank        SMALLINT NOT NULL,
    finished_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(table_id, user_id)
);

-- ─── Leaderboard ─────────────────────────────────────────
CREATE TABLE leaderboard (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    games_played INT DEFAULT 0,
    games_won    INT DEFAULT 0,
    total_points BIGINT DEFAULT 0,
    highest_score INT DEFAULT 0,
    win_streak   INT DEFAULT 0,
    best_streak  INT DEFAULT 0,
    rank_tier    SMALLINT DEFAULT 0,         -- 0=Bronze,1=Silver,2=Gold,3=Platinum,4=Diamond,5=Master
    season_pts   INT DEFAULT 0,
    updated_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_lb_rank     ON leaderboard(rank_tier DESC, season_pts DESC);
CREATE INDEX idx_lb_wins     ON leaderboard(games_won DESC);
CREATE INDEX idx_lb_streak   ON leaderboard(best_streak DESC);

-- ─── Achievements ────────────────────────────────────────
CREATE TABLE achievements (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code          VARCHAR(30) UNIQUE NOT NULL,
    name          VARCHAR(100) NOT NULL,
    description   TEXT,
    category      achievement_cat NOT NULL,
    icon          TEXT,
    requirement   JSONB NOT NULL,            -- {metric:"games_won",target:100}
    reward_chips  BIGINT DEFAULT 0,
    reward_xp     BIGINT DEFAULT 0,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_achievements (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    progress      INT DEFAULT 0,
    is_completed  BOOLEAN DEFAULT FALSE,
    completed_at  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, achievement_id)
);

-- ─── Daily Rewards ───────────────────────────────────────
CREATE TABLE daily_rewards (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day_streak  SMALLINT NOT NULL,
    reward_chips BIGINT NOT NULL,
    claimed_at  DATE NOT NULL DEFAULT CURRENT_DATE,
    UNIQUE(user_id, claimed_at)
);

CREATE INDEX idx_dr_user_date ON daily_rewards(user_id, claimed_at);

-- ─── Chat Messages ───────────────────────────────────────
CREATE TABLE chat_messages (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_id    UUID NOT NULL REFERENCES game_tables(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id),
    message     TEXT NOT NULL,
    message_type VARCHAR(10) DEFAULT 'text',  -- 'text','emoji','system'
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_chat_table  ON chat_messages(table_id, created_at);

-- ─── Transactions ────────────────────────────────────────
CREATE TABLE transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    tx_type         transaction_type NOT NULL,
    amount          BIGINT NOT NULL,
    balance_after   BIGINT NOT NULL,
    reference_id    UUID,
    reference_type  VARCHAR(30),
    description     TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tx_user ON transactions(user_id, created_at DESC);

-- ─── Packs / Loot Boxes ─────────────────────────────────
CREATE TABLE card_packs (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name          VARCHAR(100) NOT NULL,
    pack_type     pack_type NOT NULL,
    price_chips   BIGINT DEFAULT 0,
    contents      JSONB NOT NULL,             -- possible rewards
    image_url     TEXT,
    is_active     BOOLEAN DEFAULT TRUE,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_packs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    pack_id     UUID NOT NULL REFERENCES card_packs(id),
    is_opened   BOOLEAN DEFAULT FALSE,
    reward      JSONB,                       -- reward received
    acquired_at TIMESTAMPTZ DEFAULT NOW(),
    opened_at   TIMESTAMPTZ
);

-- ─── Anti-Cheat Logs ─────────────────────────────────────
CREATE TABLE fairness_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id),
    table_id    UUID REFERENCES game_tables(id),
    event_type  VARCHAR(30) NOT NULL,         -- 'shuffle_seed','deal','action_timing','pattern_detect','report'
    payload     JSONB,
    severity    SMALLINT DEFAULT 0 CHECK (severity BETWEEN 0 AND 3),
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_fl_user  ON fairness_logs(user_id);
CREATE INDEX idx_fl_table ON fairness_logs(table_id);

-- ─── Push Notification Queue ─────────────────────────────
CREATE TABLE notification_queue (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       VARCHAR(200) NOT NULL,
    body        TEXT NOT NULL,
    data        JSONB DEFAULT '{}',
    is_sent     BOOLEAN DEFAULT FALSE,
    sent_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Functions & Triggers ────────────────────────────────

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_friendships_updated_at
    BEFORE UPDATE ON friendships
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_leaderboard_updated_at
    BEFORE UPDATE ON leaderboard
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Initialize leaderboard row on user creation
CREATE OR REPLACE FUNCTION create_leaderboard_entry()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO leaderboard (user_id) VALUES (NEW.id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_leaderboard
    AFTER INSERT ON users
    FOR EACH ROW EXECUTE FUNCTION create_leaderboard_entry();

-- Insert achievements on user creation
CREATE OR REPLACE FUNCTION create_user_achievements()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO user_achievements (user_id, achievement_id)
    SELECT NEW.id, a.id FROM achievements a;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_achievements
    AFTER INSERT ON users
    FOR EACH ROW EXECUTE FUNCTION create_user_achievements();

-- ─── Seed Achievements ───────────────────────────────────
INSERT INTO achievements (code, name, description, category, reward_chips, reward_xp, requirement) VALUES
('first_game',       'First Deal',          'Play your first game of Rummy',                    'games_played', 500,   100,  '{"metric":"games_played","target":1}'),
('ten_games',        'Regular Player',      'Play 10 games',                                    'games_played', 1000,  250,  '{"metric":"games_played","target":10}'),
('hundred_games',    'Century Club',        'Play 100 games',                                   'games_played', 5000,  1000, '{"metric":"games_played","target":100}'),
('first_win',        'Maiden Victory',      'Win your first game',                              'games_won',    1000,  200,  '{"metric":"games_won","target":1}'),
('ten_wins',         'Winning Streak',      'Win 10 games',                                     'games_won',    3000,  500,  '{"metric":"games_won","target":10}'),
('three_streak',     'Hat Trick',           'Win 3 games in a row',                             'streak',       2000,  400,  '{"metric":"win_streak","target":3}'),
('five_streak',      'On Fire',             'Win 5 games in a row',                             'streak',       5000,  800,  '{"metric":"win_streak","target":5}'),
('thousand_points',  'Point Collector',     'Score 1000 points total',                          'points',       1500,  300,  '{"metric":"total_points","target":1000}'),
('perfect_declare',  'Perfect Declaration', 'Declare a valid hand with 0 deadwood points',       'special',      3000,  600,  '{"metric":"perfect_declare","target":1}'),
('first_tournament', 'Tournament Rookie',   'Participate in your first tournament',              'tournament',   2000,  400,  '{"metric":"tournament_played","target":1}'),
('five_friends',     'Social Butterfly',    'Add 5 friends',                                    'social',       1000,  200,  '{"metric":"friends_count","target":5}'),
('daily_seven',      'Weekly Warrior',      'Claim daily rewards 7 days in a row',              'special',      2500,  500,  '{"metric":"daily_streak","target":7}');

-- ─── Views ───────────────────────────────────────────────

CREATE VIEW v_leaderboard AS
SELECT
    ROW_NUMBER() OVER (ORDER BY l.rank_tier DESC, l.season_pts DESC, l.games_won DESC) AS rank,
    u.username,
    u.display_name,
    u.avatar_url,
    u.vip_level,
    l.games_played,
    l.games_won,
    CASE WHEN l.games_played > 0
         THEN ROUND(100.0 * l.games_won / l.games_played, 1)
         ELSE 0 END AS win_rate,
    l.highest_score,
    l.best_streak,
    l.rank_tier,
    l.season_pts,
    u.country
FROM leaderboard l
JOIN users u ON u.id = l.user_id
WHERE u.is_banned = FALSE
ORDER BY l.rank_tier DESC, l.season_pts DESC, l.games_won DESC;

CREATE VIEW v_active_tables AS
SELECT
    t.id,
    t.table_code,
    t.table_type,
    t.variant,
    t.max_players,
    t.entry_fee,
    t.prize_pool,
    t.turn_duration,
    t.status,
    COUNT(tp.id) AS current_players,
    u.username AS creator_name
FROM game_tables t
JOIN users u ON u.id = t.created_by
LEFT JOIN table_players tp ON tp.table_id = t.id
WHERE t.status IN ('waiting', 'in_progress')
GROUP BY t.id, u.username;

-- ============================================================
-- END OF SCHEMA
-- ============================================================
