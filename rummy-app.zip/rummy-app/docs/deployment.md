# Classic Indian Rummy — Deployment & Architecture Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Client (React Native)                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐ │
│  │ Auth Flow │ │ Lobby UI │ │ Game UI  │ │ Profile/Stats│ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └──────┬───────┘ │
│       │             │            │               │         │
│       └─────────────┴────────────┴───────────────┘         │
│                    │ REST + WebSocket                       │
└────────────────────┼────────────────────────────────────────┘
                     │
┌────────────────────┼────────────────────────────────────────┐
│              Load Balancer (Nginx / AWS ALB)                 │
└────────────────────┼────────────────────────────────────────┘
                     │
┌────────────────────┼────────────────────────────────────────┐
│           Backend (Node.js + Express + Socket.io)            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐ │
│  │Auth Svc  │ │Game Svc  │ │Socket Svc│ │Notification  │ │
│  │          │ │(Engine)  │ │(Room Mgmt│ │Svc (FCM/APNs)│ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └──────┬───────┘ │
└───────┼────────────┼────────────┼──────────────┼──────────┘
        │            │            │              │
   ┌────┴────────────┴────────────┴──────────────┴────┐
   │              PostgreSQL 15 + Redis                 │
   │  ┌──────────┐  ┌──────────┐  ┌──────────────────┐│
   │  │ Users DB │  │Game Data │  │Session/Cache Data││
   │  └──────────┘  └──────────┘  └──────────────────┘│
   └──────────────────────────────────────────────────┘
```

## Prerequisites

- **Node.js** 18+ (backend)
- **PostgreSQL** 15+
- **Redis** 7+ (optional, for horizontal scaling)
- **React Native** 0.73+ (frontend)
- **Android Studio** / **Xcode** (mobile builds)

## 1. Database Setup

```bash
# Install PostgreSQL 15
# Ubuntu/Debian:
sudo apt install postgresql-15

# macOS:
brew install postgresql@15

# Create database and user
sudo -u postgres psql
```

```sql
CREATE USER rummy_user WITH PASSWORD 'your_secure_password';
CREATE DATABASE rummy_db OWNER rummy_user;
\c rummy_db
GRANT ALL PRIVILEGES ON DATABASE rummy_db TO rummy_user;
\q
```

```bash
# Run schema migration
psql -U rummy_user -d rummy_db -f database/schema.sql
```

## 2. Backend Deployment

### Option A: Docker (Recommended)

```dockerfile
# Dockerfile (place in backend/)
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY src/ ./src/
EXPOSE 3000
CMD ["node", "src/server.js"]
```

```bash
# docker-compose.yml
version: '3.8'
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: rummy_user
      POSTGRES_PASSWORD: rummy_pass
      POSTGRES_DB: rummy_db
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./database/schema.sql:/docker-entrypoint-initdb.d/schema.sql

  redis:
    image: redis:7-alpine

  backend:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://rummy_user:rummy_pass@postgres:5432/rummy_db
      REDIS_URL: redis://redis:6379
      JWT_SECRET: your-production-secret-key
      NODE_ENV: production
    depends_on:
      - postgres
      - redis

volumes:
  pgdata:
```

```bash
docker-compose up -d
```

### Option B: Manual / VPS

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Clone and setup
cd /opt
git clone your-repo rummy-backend
cd rummy-backend/backend
npm ci --production

# Configure environment
cp .env.example .env
nano .env  # Edit with production values

# Install PM2 for process management
npm install -g pm2
pm2 start src/server.js --name rummy-backend
pm2 save
pm2 startup
```

### Environment Variables (Production)

```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://rummy_user:STRONG_PASSWORD@localhost:5432/rummy_db
REDIS_URL=redis://localhost:6379
JWT_SECRET=64-char-random-string
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=30d
CARD_ENCRYPTION_KEY=32-byte-hex-encoded-key
CORS_ORIGIN=https://yourdomain.com
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=60
```

### Nginx Reverse Proxy

```nginx
server {
    listen 443 ssl http2;
    server_name api.rummyclassic.com;

    ssl_certificate /etc/letsencrypt/live/api.rummyclassic.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.rummyclassic.com/privkey.pem;

    # REST API
    location /api/ {
        proxy_pass http://localhost:3000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket
    location /ws/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
    }
}
```

## 3. Frontend Deployment

### Development

```bash
cd frontend
npm install

# iOS
cd ios && pod install && cd ..
npx react-native run-ios

# Android
npx react-native run-android
```

### Production Build

```bash
# Android (.aab for Play Store)
cd android
./gradlew bundleRelease

# iOS (.ipa for App Store)
# Use Xcode: Product → Archive → Distribute App
```

### Update API URL for Production

In `frontend/src/services/api.js`:
```js
const API_BASE = 'https://api.rummyclassic.com/api/v1';
const WS_BASE = 'wss://api.rummyclassic.com';
```

### App Store Assets

Required (in `frontend/src/assets/`):
- `icon.png` — 1024x1024 app icon
- `splash.png` — 1242x2688 splash screen
- `adaptive-icon.png` — 1024x1024 Android adaptive icon

## 4. Push Notifications Setup

### Firebase Cloud Messaging (Android)

1. Create project at https://console.firebase.google.com
2. Add Android app with package name
3. Download `google-services.json` → place in `android/app/`
4. Get Server Key from Project Settings → Cloud Messaging
5. Set `FCM_SERVER_KEY` in backend `.env`

### Apple Push Notifications (iOS)

1. Apple Developer → Certificates → Apple Push Notification service SSL
2. Generate APNs key (`.p8` file)
3. Set in backend `.env`:
   ```
   APNS_KEY_ID=XXXXXXXXXX
   APNS_TEAM_ID=XXXXXXXXXX
   ```

## 5. Scaling Strategy

### Horizontal Scaling with Redis

For production with multiple backend instances:
- Redis is used as the Socket.io adapter (`socket.io-redis`)
- This ensures all instances share WebSocket state
- Game engines must move to Redis for true horizontal scaling

```bash
# Scale backend with PM2
pm2 start src/server.js -i max --name rummy-backend
```

### Database Optimization

```sql
-- Connection pooling is built in (min: 2, max: 20)
-- Add read replicas for heavy read workloads
-- Consider partitioning game_actions by date
-- Regular VACUUM ANALYZE for performance
```

## 6. Anti-Cheat & Fair Play

### Implemented Measures

1. **Provably Fair Shuffling**: Server generates a random seed before each round and publishes its SHA-256 hash. The seed is revealed after the round ends, allowing players to verify the deck order.

2. **Action Timing Analysis**: `fairness_logs` table tracks suspicious patterns (instant decisions, unusual win rates).

3. **Card State Validation**: Every game action is server-authoritative. The server maintains the source of truth for all card positions.

4. **Replay System**: Complete game history allows auditing of any suspicious game.

### Additional Recommendations

- **ML-based anomaly detection**: Train a model to flag unusual play patterns
- **IP/device fingerprinting**: Prevent multi-accounting
- **VPN/proxy detection**: Block known VPN IPs for real-money games
- **Regular security audits**: Third-party testing of RNG and game logic

## 7. Monitoring

```bash
# Health check endpoint
curl https://api.rummyclassic.com/health

# Recommended monitoring tools:
# - PM2 + Keymetrics for process monitoring
# - Prometheus + Grafana for metrics
# - Sentry for error tracking
# - PostgreSQL pg_stat_statements for query analysis
```

## 8. Cost Estimate (Monthly)

| Service | Provider | Approx. Cost |
|---------|----------|--------------|
| Backend (2 vCPU, 4GB) | AWS EC2 / DigitalOcean | $40-80 |
| PostgreSQL (managed) | AWS RDS / Supabase | $25-50 |
| Redis (managed) | Upstash / Redis Cloud | $0-20 (free tier available) |
| CDN (assets) | Cloudflare | Free |
| Push notifications | Firebase (free) | Free |
| Domain + SSL | Any registrar + Let's Encrypt | $12/year |
| **Total** | | **~$70-150/month** |

## Quick Start (Local Dev)

```bash
# Terminal 1: Database
docker run -d --name rummy-pg \
  -e POSTGRES_USER=rummy_user \
  -e POSTGRES_PASSWORD=rummy_pass \
  -e POSTGRES_DB=rummy_db \
  -p 5432:5432 \
  postgres:15-alpine

# Terminal 2: Backend
cd backend
cp .env.example .env
npm install
npm run dev

# Terminal 3: Frontend
cd frontend
npm install
npx react-native start

# Terminal 4: iOS/Android
cd frontend
npx react-native run-ios  # or run-android
```

The API will be available at `http://localhost:3000/api/v1` and WebSocket at `ws://localhost:3000`.
