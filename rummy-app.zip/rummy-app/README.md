# 🃏 Classic Indian Rummy

A modern, full-stack mobile card game application inspired by the classic Indian Rummy — built with React Native, Node.js, PostgreSQL, and Socket.io.

## Features

### 🎮 Core Gameplay
- **13-Card Indian Rummy** — Points, Deals, Pool 101, and Pool 201 variants
- **Real-time multiplayer** — 2-6 players per table
- **Card drag & drop** — Intuitive touch-based card arrangement
- **Smart sorting** — Sort by suit or rank with one tap
- **Auto-meld detection** — Instant suggestions for valid sequences and sets
- **Pure sequence enforcement** — Strict Indian Rummy rules validation
- **Turn timer** — Configurable per table (10-120 seconds)
- **Drop option** — First-turn drop (20 pts) / mid-game drop (40 pts)

### 🏠 Lobby & Social
- **Quick Play** — Auto-match into a public table
- **Private Tables** — Play with friends via 6-digit join code
- **Friend System** — Add friends, see online status, invite to games
- **In-game Chat** — Real-time messaging at the table
- **Spectator Mode** — Watch ongoing games

### 🏆 Progression
- **Chips Economy** — Earn and spend virtual chips
- **Leaderboard** — Global and friends-only rankings
- **Achievements** — 12+ unlockable achievements with chip/XP rewards
- **Daily Rewards** — 7-day streak system with escalating bonuses
- **Rank Tiers** — Bronze → Silver → Gold → Platinum → Diamond → Master
- **VIP Levels** — Premium progression system

### 🔐 Security & Fair Play
- **Provably Fair Shuffle** — SHA-256 seed hashing for verifiable randomness
- **Server-Authoritative** — All game logic validated server-side
- **Anti-Cheat Logging** — Pattern detection and timing analysis
- **Replay System** — Full round-by-round game history
- **JWT Authentication** — Secure token-based auth with refresh rotation

### 🎨 UI/UX
- **Light & Dark Mode** — System-aware theming
- **Smooth Animations** — Card dealing, turn transitions, modal slides
- **Responsive Layout** — Works on phones and tablets
- **Push Notifications** — FCM (Android) / APNs (iOS) for turn alerts
- **Accessible Design** — Color-blind friendly card indicators

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React Native 0.73, React Navigation 6, Zustand, Socket.io Client |
| **Backend** | Node.js 18, Express 4, Socket.io 4 |
| **Database** | PostgreSQL 15 (with UUID, JSONB, full-text) |
| **Cache** | Redis 7 (optional, for horizontal scaling) |
| **Auth** | JWT (access + refresh tokens), bcryptjs |
| **Push** | Firebase Cloud Messaging, Apple Push Notification Service |
| **Validation** | Zod (request schemas), express-rate-limit |
| **Logging** | Winston (structured JSON logging) |

## Project Structure

```
rummy-app/
├── backend/
│   └── src/
│       ├── config/          # DB, Redis, Logger, Environment
│       ├── middleware/       # Auth, Validation, Rate Limiting
│       ├── models/          # Database query helpers
│       ├── routes/          # REST API routes
│       │   ├── auth.js      # Register, Login, Refresh, Logout
│       │   ├── users.js     # Profiles, Stats, Search
│       │   ├── friends.js   # Friend management
│       │   ├── tables.js    # Lobby, Create/Join tables
│       │   ├── leaderboard.js
│       │   ├── achievements.js
│       │   ├── dailyRewards.js
│       │   └── games.js     # History, Replay, Transactions
│       ├── services/
│       │   ├── gameEngine.js    # Core Rummy game logic
│       │   └── notifications.js # Push notification dispatch
│       ├── socket/
│       │   └── gameSocket.js    # WebSocket game server
│       ├── utils/
│       │   ├── cards.js         # Deck, shuffle, deal
│       │   └── validator.js     # Meld/declaration validation
│       └── server.js            # Entry point
├── frontend/
│   └── src/
│       ├── components/      # Reusable UI components
│       ├── screens/
│       │   ├── LoginScreen.js
│       │   ├── RegisterScreen.js
│       │   ├── HomeScreen.js        # Dashboard
│       │   ├── GameScreen.js        # Main gameplay
│       │   ├── TablesScreen.js      # Lobby
│       │   ├── FriendsScreen.js     # Social
│       │   ├── ProfileScreen.js     # Stats + Settings
│       │   ├── RoundResultsScreen.js
│       │   ├── GameHistoryScreen.js
│       │   └── GameReplayScreen.js
│       ├── store/           # Zustand state management
│       ├── services/        # API client + Socket.io manager
│       ├── navigation/      # React Navigation stacks
│       ├── theme/           # Light/Dark design system
│       └── utils/           # Card helpers, meld finder
├── database/
│   └── schema.sql           # Complete PostgreSQL schema
└── docs/
    ├── api-reference.md     # Full REST + WebSocket API
    └── deployment.md        # Deployment + scaling guide
```

## Quick Start

```bash
# 1. Clone and setup database
docker run -d --name rummy-pg \
  -e POSTGRES_USER=rummy_user \
  -e POSTGRES_PASSWORD=rummy_pass \
  -e POSTGRES_DB=rummy_db \
  -p 5432:5432 postgres:15-alpine

psql -h localhost -U rummy_user -d rummy_db -f database/schema.sql

# 2. Start backend
cd backend
cp .env.example .env
npm install && npm run dev

# 3. Start frontend
cd frontend
npm install
npx react-native start
# In another terminal:
npx react-native run-ios  # or run-android
```

## API Highlights

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | User registration |
| POST | `/api/v1/auth/login` | Login |
| GET | `/api/v1/tables` | List active tables |
| POST | `/api/v1/tables` | Create table |
| POST | `/api/v1/tables/join-by-code` | Join via code |
| GET | `/api/v1/leaderboard` | Global rankings |
| GET | `/api/v1/achievements` | Achievement progress |
| POST | `/api/v1/daily-rewards/claim` | Claim daily bonus |
| GET | `/api/v1/games/history` | Game history |
| GET | `/api/v1/games/:id/replay` | Game replay data |
| WS | `ws://host/ws?token=` | Real-time game (Socket.io) |

Full API reference: [docs/api-reference.md](docs/api-reference.md)

## WebSocket Events

### Client → Server
- `game:draw_pile`, `game:draw_discard`, `game:discard`
- `game:declare`, `game:drop`
- `game:reorder`, `game:sort`
- `chat:send`

### Server → Client
- `game:dealt`, `game:turn`, `game:state`
- `game:card_drawn`, `game:card_discarded`, `game:declared`
- `game:round_end`, `game:player_joined`, `game:player_left`
- `chat:message`

## Deployment

See [docs/deployment.md](docs/deployment.md) for:
- Docker / Docker Compose setup
- Nginx reverse proxy configuration
- Push notification setup (FCM + APNs)
- Horizontal scaling with Redis
- Anti-cheat implementation details
- Cost estimates

## License

Proprietary. All rights reserved.
